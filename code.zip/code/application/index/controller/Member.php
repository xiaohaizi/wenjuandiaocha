<?php
namespace app\index\controller;

class Member
{
    public function index()
    {
        
        return view();
    }
}
