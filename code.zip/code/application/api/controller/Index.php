<?php
namespace app\api\controller;

class Index
{
    public function index(){
        
        
    }
}